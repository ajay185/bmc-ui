import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class DataService {
    userName = 'admin';
    password = 'secret';
    appUrl = 'https://r09ajnx3ye.execute-api.us-east-1.amazonaws.com/retailer/';

    appUrl_manufacturer = 'http://3.86.106.125:30231/';

    private readonly auth = new HttpHeaders()
        .set("Authorization", 'Basic ' + btoa(this.userName + ":" + this.password));

    constructor(private _http: HttpClient) {

    }

    createDelivery(deliveryPayloadData: string) {
        console.log(deliveryPayloadData);
        return this._http.post(this.appUrl_manufacturer + "doctors",
        deliveryPayloadData
        );
    }

}