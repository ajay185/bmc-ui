export class MaterialProductionOrder {
    ProductionOrderID: string;
    Owner: string;
    Deleted: boolean;
}