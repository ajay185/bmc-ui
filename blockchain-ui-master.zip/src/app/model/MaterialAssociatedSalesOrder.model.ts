export class MaterialAssociatedSalesOrder {
    SalesOrderID: string;
    Owner: string;
    Deleted: boolean
}