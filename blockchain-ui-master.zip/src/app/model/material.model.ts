import { MaterialBatches } from './MaterialBatches.model';
import { MaterialProductionOrder } from './MaterialProductionOrder.model';
import { MaterialPurchaseOrder } from './MaterialPurchaseOrder.model';

export class Material {
        Asset_Type: string;
        MaterialID: string;
        OpenPurchaseOrders: MaterialPurchaseOrder[];
        ClosedPurchaseOrders: MaterialPurchaseOrder[];
        ProductionOrders: MaterialProductionOrder[];
        ActiveBatches: MaterialBatches[];
        Batches: MaterialBatches[];
}