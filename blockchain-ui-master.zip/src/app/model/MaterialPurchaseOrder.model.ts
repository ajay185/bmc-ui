import { MaterialAssociatedSalesOrder } from './MaterialAssociatedSalesOrder.model';
export class MaterialPurchaseOrder {
    PurchaseOrderID: string;
    Owner:string;
    AssociatedSalesOrders: MaterialAssociatedSalesOrder[];
    Deleted: boolean;
}