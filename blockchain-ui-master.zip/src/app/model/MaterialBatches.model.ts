export class MaterialBatches {
    BatchNumber: string;
    Owner: string;
    Deleted: boolean;
}