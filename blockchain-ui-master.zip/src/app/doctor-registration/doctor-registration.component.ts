import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../service/data.service';
import { AlertService } from 'app/service/alert.service';

@Component({
    selector: 'app-doctor-registration',
    templateUrl: './doctor-registration.component.html',
    styleUrls: ['./doctor-registration.component.css']
})
export class DoctorRegistrationComponent implements OnInit {
    registerForm: FormGroup;
    submitted = false;

    constructor(private formBuilder: FormBuilder, private dataService: DataService,
        private alertService: AlertService) { }

    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            id: ['', Validators.required],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            dob: ['', Validators.required],
            speciality: ['', Validators.required],
            mobile: ['', Validators.required],
            emailId: ['', Validators.required]

        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }
        // display form values on success
        let inputVar = JSON.stringify(this.registerForm.value);

        console.log(inputVar);
        this.dataService.createDelivery(inputVar).subscribe((data: string) => {
            this.alertService.success('Doctor Registration Success !!! ');
        }, err => {
            console.log(err);
            this.alertService.error('Doctor Registration Failed');
        });
    }

    onReset() {
        this.submitted = false;
        this.registerForm.reset();
    }

}
