import { DataService } from './../../service/data.service';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routing';

import {
  MatButtonModule,
  MatInputModule,
  MatRippleModule,
  MatFormFieldModule,
  MatTooltipModule,
  MatSelectModule,
  MatProgressSpinnerModule
} from '@angular/material';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerComponent } from 'app/spinner/spinner.component';
import { BlockUIModule } from 'ng-block-ui';
import { AlertService } from 'app/service/alert.service';
import { AlertComponent } from 'app/alert/alert.component';
import { DoctorRegistrationComponent } from 'app/doctor-registration/doctor-registration.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    NgbModule,
    MatProgressSpinnerModule,
    BlockUIModule.forRoot()
  ],
  declarations: [
    SpinnerComponent,
    AlertComponent,
    DoctorRegistrationComponent
  ],
  entryComponents: [],
  providers: [DataService, AlertService]
})

export class AdminLayoutModule { }
