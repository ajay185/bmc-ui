import { Routes } from '@angular/router';
import { DoctorRegistrationComponent } from 'app/doctor-registration/doctor-registration.component';

export const AdminLayoutRoutes: Routes = [
    { path: 'doctorRegistration', component: DoctorRegistrationComponent }
];
