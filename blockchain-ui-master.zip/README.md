# Deployment
Make sure you have node and the Angular CLI installed before proceeding.

Clone this repository to your local machine, and open the root blockchain-ui folder inside your editor.

Open a terminal window, and run the following commands inside the root blockchain-ui folder:
```
npm install
ng serve
```
Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

When satisfied with your changes, run the following command in Terminal: 
```
ng build
```

This compiles the code into a distribution folder /dist/. 

Use the Amazon S3 console to create a bucket and to upload your website files.

Create a CloudFront web distribution. In addition to the distribution settings that you need for your use case, enter the following:
- For Origin Domain Name, select the bucket that you created.
- For Restrict Bucket Access, select Yes.
- For Origin Access Identity, select Create a New Identity.
- For Comment, you can choose to keep the default value. Or, you can enter a custom label for the OAI.
- For Grant Read Permissions on Bucket, select Yes, Update Bucket Policy.
- Choose Create Distribution.
- Update the DNS records for your domain to point your website's CNAME to your CloudFront distribution's domain name. You can find your distribution's domain name in the CloudFront console in a format that's similar to d1234abcd.cloudfront.net.
- Wait for your DNS changes to propagate and for the previous DNS entries to expire.
Using a website endpoint as the origin, with anonymous (public) access allowed
# BlockchainApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 8.3.16.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
